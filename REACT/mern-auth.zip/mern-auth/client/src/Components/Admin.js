import React from 'react'
import Navbar from './Navbar'

const Admin = () => {
    return (
        <Navbar>
            <h2>Admin page</h2>
        </Navbar>
    )
}

export default Admin