import React from 'react';

import Navbar from './Navbar'

const Private = () => {
    return (
        <Navbar>
            <h1>Hello</h1>
        </Navbar>
    )
}

export default Private